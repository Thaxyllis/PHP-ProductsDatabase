<?php
	define("MYSQL_HOST", "subdomain.host.com");
	define("MYSQL_DB", "database_name");
	define("MYSQL_CHAR", "utf8");
	define("MYSQL_USER", "database_user");
	define("MYSQL_PASS", "database_pass");	
?>